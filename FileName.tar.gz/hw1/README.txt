First, please direct to folder 'hw1'.

And type 'make' on terminal to compile hw1_1.cpp and bonus.cpp

You can find executable file 1_1 ------- for homework 1-1 

				and file my_fork ------- for homework bonus 

For homework 1-1 :

	This program would only support for specific one program to execute.
	
	And its format is : ./1_1 _PROGRAM_NAME
	
	And you can checkout the execution result.

For homework 1-2 :

	Temporarily will not offer any service ...... 

	I will be back ... 

For Bonus :

	This program can support AT LEAST one program to exeucute.

	And its format is ./my_fork PROGRAM_1 PROGRAM_2 PROGRAM_3 ....... 

	When begining to execute, you can checkout the relationship between Parent and Child.
	
	( You will see the ascendent pid number arranged in one of first four lines :)
	
	And next, you will see the execution result and signal result for each child process.

-------------------------
Extra remind:

	"testcase" folder contains my testcases which are all executable files for homework 1-1 and bonus,

	and "testsource" folder contains my testcase program resources. 

	"kernel_object" folder contains LINUX kernel code.

	But it does NOT offer any service currently.