#include <cstdio>

using namespace std;

int main(){

    int x = 0 ;
    int y = 0 ;
    printf("%d\n",x/y) ;

    return 0; 
}
