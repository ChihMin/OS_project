#include <cstdio>

using namespace std;

int main(){

	while( 1 ) ; 

	return 0; 
}
