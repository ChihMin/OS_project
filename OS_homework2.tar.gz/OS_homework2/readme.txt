For homework 1 : 
	
	At first, you need to compile 'hw2.cpp' file ,

	and just type 'g++ hw2.cpp -lpthread' on concole.

	How to execute? Just type './a.out' is okay :)

	On the screen, you can see a frog is at buttom. 

	You need to step on the woods to cross over the river.

	Of course, you can move left and right on river free. 

	This is wood ----> ================== 

	This is frog ----> O

	If you are flush away(out of screen) or drop into water, you will die :(

	Pay attention : the most-right-sided wood is vulnerable 

	Therefore, you can't step here : ==================
	                                                  ^
	or you will die also :D. 

For Bonus : 

	If you want to compile it, you need to install extra library in Linux or Mac.

	For ubuntu : apt-get install qt-dev-tools 

	For Mac you need to install Homebrew first : brew install qt   

	I use QT to implement my GUI frog game. 

	How to compile ? 

	1. qmake -porject
	2. qmake 
	3. make 
	4. execute files 

	It make sence the frog is miku ... ( maybe just they have the same color :) )

	And the wood is Scallion ... ( for some reason I select Scallion :D )

	The rule is the same as hw2 ... 

	And there's speed bar on left buttom for you to adjust the river speed.
	