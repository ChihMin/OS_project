OS_HW5:

	1. Type 'make' on console, it will compile and automatically insmod to kernel

	2. type 'sudo sh mkdev.sh' to register the device, the path is '/dev/mydev'

	3. In the first part, it also compiles test.c, so just run ./test to test

	4. type 'make clean' to check the result, and 'sudo sh rmdev.sh' to remove dev.





