First, you need th change directory to OS_Homework3

How to compile ?

1. Type 'make' on command 

2. prepare data.bin for input

3. Execute ./mvm

4. After Execution, pagefault = x , x is the number of pagefault,

   and snapshot.bin is the result of execution.


